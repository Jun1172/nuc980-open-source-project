#!/bin/bash
# Copyright (c) Nuvoton Tech. Corp. All rights reserved.
# Description:	NUC980 Linux BSP install script
# Version:		2019-01-24
ROOT_UID=0
if [ "$UID" -ne "$ROOT_UID" ] ;then
	echo 'Sorry, you are not root !!'
	exit 1
fi

ARM_TOOL_ROOT="/usr/local"
ARM_TOOL_NANE="arm_linux_4.8"
ARM_TOOL_PATH="$ARM_TOOL_ROOT/$ARM_TOOL_NANE"

NO_TOOL=0
if [ -d $ARM_TOOL_PATH ]; then
	echo "The folder \"$ARM_TOOL_PATH\" is already existed, continue the tool chain installation?(Y/N)"
	INSTALL=1
	while [ $INSTALL == 1 ]
	do
		read install
		case "$install" in
		[yY]|[yY][eE][sS] )
			INSTALL=0
			;;
		[nN]|[nN][oO] )
			echo "Skip tool chain installation"
			INSTALL=2
			NO_TOOL=1
			;;
		* )
			echo "Please type yes or no!"
			;;
		esac
	done
	if [ $NO_TOOL == 0 ]; then
		echo "Do you want to remove this folder first?(Y/N)"
		REMOVE=1
		while [ $REMOVE == 1 ]
		do
			read remove
			case "$remove" in
			[yY]|[yY][eE][sS] )
				echo "Now deleting the folder \"$ARM_TOOL_PATH\"..."
				rm -rf $ARM_TOOL_PATH
				REMOVE=0
				;;
			[nN]|[nN][oO] )
				echo "This installation will overwrite folder \"$ARM_TOOL_PATH\"!"
				REMOVE=0
				;;
			* )
				echo "Please type yes or no!"
				;;
			esac
		done
	fi
fi

if [ $NO_TOOL == 0 ]; then
	echo "Now installing $ARM_TOOL_NANE tool chain to $ARM_TOOL_ROOT"
	mkdir -p $ARM_TOOL_ROOT
	tar --directory=$ARM_TOOL_ROOT -zxf $ARM_TOOL_NANE.tar.gz&
	pid=`echo $!`
	str="| / - \\"
	count=1
	while [ -d /proc/$pid ]
	do
		if [ $count == 5 ]; then
			count=1
		fi
		echo -e -n "\r"`echo $str | awk '{print $'$count'}'`
		count=`expr $count + 1`
		sleep 1
	done
	chown root:root -R $ARM_TOOL_PATH
	echo -e -n '\r'
fi

echo "Setting tool chain environment"
PROFILE=/etc/profile
NVTFILE=/etc/profile.d/nvt_arm_linux.sh
TMPFILE=`mktemp -q /tmp/$0.XXXXXX`
if [ $? -ne 0 ]; then
	echo "$0: Can't create temp file, exiting..."
	exit 1
fi

# Check tool chain environment setting in PROFILE
REC=$(cat $PROFILE|tr -d '\r'|tr -t '\n' '\r'|sed '1,$s/\\//g' |tr -t '\r' '\n'|grep "PATH="|sed '1,$s/PATH=//g'|tr -t '\n' ':')
NUM=$(echo $REC|awk -F: 'END {print NF}')
i=1
RES=0
while (test $i -le $NUM)
do
	TMP=$(echo $REC | awk -F: "{print \$$i}")
	if [ "$TMP" = "$ARM_TOOL_PATH/bin" ]; then
		RES=1
	elif [ "$TMP" = "$ARM_TOOL_PATH/bin/" ]; then
		RES=1
	fi
	i=`expr $i + 1`
done

# Check tool chain environment setting in NVTFILE
if [ $RES == 0 ]; then
	if [ -f $NVTFILE ]; then
		cat $NVTFILE | grep "^[ ]*export PATH=$ARM_TOOL_PATH/bin" > /dev/null
		if [ $? == 0 ]; then
			RES=1
		fi
	fi
fi

if [ $RES == 1 ]; then
	echo > /dev/null
else
	if [ -f $NVTFILE ]; then
		cat $NVTFILE | grep	 "^[ ]*export " > /dev/null
		if [ $? == 0 ]; then
			ARM_TOOL_PATH_TMP=`echo $ARM_TOOL_PATH | sed -e 's/\//\\\\\//g'`
			cat $NVTFILE | grep	 "^[ ]*export " | grep "$ARM_TOOL_PATH/bin" > /dev/null
			if [ $? == 0 ]; then
				sed -e 's/'$ARM_TOOL_PATH_TMP'\/bin[/]*://' $NVTFILE > $TMPFILE
				cp -f $TMPFILE $NVTFILE
			fi
			sed -e 's/PATH=/PATH='$ARM_TOOL_PATH_TMP'\/bin:/' $NVTFILE > $TMPFILE
			cp -f $TMPFILE $NVTFILE
			rm -f $TMPFILE
		else
			echo 'export PATH='$ARM_TOOL_PATH'/bin:$PATH' >> $NVTFILE
		fi
	else
		echo '## Nuvoton toolchain environment export' >> $NVTFILE
		echo 'export PATH='$ARM_TOOL_PATH'/bin:$PATH' >> $NVTFILE
		chmod +x $NVTFILE
	fi
fi

echo "Installing $ARM_TOOL_NANE tool chain successfully"

echo "Install rootfs and pre-build image"
echo "Please enter absolute path for installing(eg:/home/<user name>) :"
echo "BSP will be installed in /<path you input>"
read letter

if [ ! -d $letter ] ;then
	echo 'Create '$letter' ';
	mkdir $letter;
fi

echo $letter/nuc980bsp
 Check if nuc980bsp directory exist. If not, create it
if [ ! -d $letter/nuc980bsp ]; then
	mkdir $letter/nuc980bsp;
fi

echo 'Extract rootfs and pre-built images';
tar --directory=$letter/nuc980bsp -z -x -f rootfs.tar.gz;
tar --directory=$letter/nuc980bsp -z -x -f image.tar.gz;


find $letter -type d|xargs chmod 755
if [ -z $SUDO_USER ];then
		chown -R $USER:$USER $letter;
else
		chown -R $SUDO_USER:$SUDO_USER $letter;
fi
echo -e '\rNUC980 BSP installation complete'
